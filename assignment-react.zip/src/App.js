import './App.css';
import React from 'react';
import Statedata from './Components/Statedata';

function App() {
  return (
    <div>
      <Statedata/>
    </div>
  )
}

export default App;
